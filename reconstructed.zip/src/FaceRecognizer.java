

// FaceRecognizer.java
// Andrew Davison, April 2011, ad@fivedots.psu.ac.th
//Modified by MANISH TIWARI
/* Show a sequence of images snapped from a webcam in a picture panel (FaceRecogPanel). 
 * A face is highlighted with a yellow rectangle, which is updated as the face
 * moves. The highlighted part of the image can be recognized by the user pressing
 * the "Recognize Face" button.
*/

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.RasterFormatException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import com.googlecode.javacv.cpp.opencv_core.*;

import com.googlecode.javacv.cpp.opencv_objdetect;

import de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel;

import com.googlecode.javacpp.Loader;


public class FaceRecognizer extends JFrame 
{	
	private static final long serialVersionUID = 1L;
	static JLabel labelStatus=new JLabel();
	private int fileCount = 0;// for saving a detected face image
	private static final String FACE_DIR = "trainingImages"; 
	private static final int FACE_WIDTH = 125;
	private static final int FACE_HEIGHT = 150;	
	static String FACE_FNM;// JavaCV variables
	private IplImage grayIm;
	
	// GUI components
	public static FaceRecogPanel facePanel;
	//private JButton recogBut;// where the name (and distance info) appears
	static JButton saveBut; 
	public FaceRecognizer() throws InvocationTargetException, InterruptedException
	{
		super("Face Recognizer");
		Container c = getContentPane();
		c.setLayout( new BorderLayout() );   // Preload the opencv_objdetect module to work around a known bug.
		Loader.load(opencv_objdetect.class);
		facePanel = new FaceRecogPanel(this); // the sequence of pictures appear here
		c.add( facePanel, BorderLayout.CENTER);// button for recognizing a highlighted face
		
		saveBut = new JButton("Save Face"); 
		JPanel p = new JPanel();
		
		p.add(saveBut);
		p.add(labelStatus); 
		c.add(p, BorderLayout.SOUTH);
		saveBut.addActionListener(new ActionListener()
		{	
			public void actionPerformed(ActionEvent arg0)
			{
				IplImage im;
				try 
				{
					FaceRecogPanel.result=null;
					saveBut.setEnabled(false);
					byte i=0;
					//For Efficient Result,Its Mandatory To Take 13 Pictures.
					JOptionPane.showMessageDialog(null,"Whenever You Want To Go Out Just Click On 'NO',REMEMBER NO");
					
					int	choice=JOptionPane.showConfirmDialog(null,"For Efficient Result,Its Mandatory To Take 13 Pictures.","Confirmation Box",JOptionPane.OK_CANCEL_OPTION);
					if(choice==JOptionPane.OK_OPTION)
					{
					do{
						FACE_FNM=JOptionPane.showInputDialog(null,"Enter The Name","Name",JOptionPane.OK_CANCEL_OPTION);
					}while(FACE_FNM==null);
					do
					{
					choice= JOptionPane.showConfirmDialog(null,"Please Change the Pose Of Your Face,For Efficient Result Please Take Different-Different Type Of Faces.","Confirmation Box",JOptionPane.OK_CANCEL_OPTION);
					if(choice==JOptionPane.CANCEL_OPTION)
					{break;}
					choice=JOptionPane.showConfirmDialog(null,"Are You Ready,'No' if You Want To Quit.","Confirmation Box",JOptionPane.YES_NO_OPTION);
					
					if(choice==1)
					{
						 choice=JOptionPane.showConfirmDialog(null,"Do You Want To Close?","Confirmation Box",JOptionPane.YES_NO_OPTION);
						if(choice==0)
						{break;}
					}
					SpeakName.voiceName="mbrola_us1";
					Loading.objSpeak.speak("Smile...");
					SpeakName.voiceName="kevin16";
					im = FaceRecogPanel.grabber.grab();
					clipSaveFace(im);
					i++;
					}while(i!=13);
					}Runtime rt=Runtime.getRuntime();
					rt.exec("java Loading");
					
					System.exit(0);
				}
				catch (Exception e){/*Do Not Write ANything*/		}
			}
		});
		addWindowListener( new WindowAdapter() 
		{
			public void windowClosing(WindowEvent e)
			{
				facePanel.closeDown();   // stop snapping pics
				System.exit(0);
			}
		});
		pack();  
		setResizable(false);
		setVisible(true);
	} // end of FaceRecognizer()
  
  

	
  // -------------------------------------------------------

 // ---------------- face saving -------------------------

	private void clipSaveFace(IplImage img)
	/*
	 *  clip the image using the current face rectangle, and save it into fnm
     *	The use of faceRect is in a synchronized block since it may be being
     *	updated or used for drawing at the same time in other threads.
     */
	{	  
		BufferedImage clipIm = null;
		synchronized(FaceRecogPanel.faceRect)
		{
			if (FaceRecogPanel.faceRect.width == 0)
			{
				System.out.println("No face selected");
				return;
			}
			BufferedImage im = img.getBufferedImage();
			try 
			{
				clipIm = im.getSubimage(FaceRecogPanel.faceRect.x, FaceRecogPanel.faceRect.y, FaceRecogPanel.faceRect.width,FaceRecogPanel. faceRect.height);
			}
			catch(RasterFormatException e)
			{
				System.out.println("Could not clip the image");
			}
		}
		if (clipIm != null)
			saveClip(clipIm);
	}  // end of clipSaveFace()
	
	private void saveClip(BufferedImage clipIm)
	/*
	 *  resizes to at least a standard size, converts to grayscale, 
     *	clips to an exact size, then saves in a standard location 
     */
	{
		long startTime = System.currentTimeMillis();
		System.out.println("Saving clip...");
		BufferedImage grayIm = resizeImage(clipIm);  
		BufferedImage faceIm = clipToFace(grayIm);
		saveImage(faceIm, FACE_DIR + "/" + FACE_FNM + fileCount + ".png");
		fileCount++;
		System.out.println("  Save time: " + (System.currentTimeMillis() - startTime) + " ms");
	}  // end of saveClip()

	private BufferedImage resizeImage(BufferedImage im)
	// resize to at least a standard size, then convert to grayscale 
	{
		// resize the image so *at least* FACE_WIDTH*FACE_HEIGHT size
		int imWidth = im.getWidth();
		int imHeight = im.getHeight();
		System.out.println("Original (w,h): (" + imWidth + ", " + imHeight + ")");

		double widthScale = FACE_WIDTH / ((double) imWidth);
		double heightScale = FACE_HEIGHT / ((double) imHeight);
		double scale = (widthScale > heightScale) ? widthScale : heightScale;

		int nWidth = (int)Math.round(imWidth* scale);
		int nHeight = (int)Math.round(imHeight* scale);

		// convert to grayscale while resizing
		BufferedImage grayIm = new BufferedImage(nWidth, nHeight,BufferedImage.TYPE_BYTE_GRAY);  
		Graphics2D g2 = grayIm.createGraphics();
		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(im, 0, 0, nWidth, nHeight,  0, 0, imWidth, imHeight, null);  
		g2.dispose();  
		System.out.println("Scaled gray (w,h): (" + nWidth + ", " + nHeight + ")");
		return grayIm;
	}  // end of resizeImage()

	private BufferedImage clipToFace(BufferedImage im)
	// clip image to FACE_WIDTH*FACE_HEIGHT size
	// I assume the input image is face size or bigger
	{
		int xOffset = (im.getWidth() - FACE_WIDTH)/2;
		int yOffset = (im.getHeight() - FACE_HEIGHT)/2;
		BufferedImage faceIm = null;
		try
		{
			faceIm = im.getSubimage(xOffset, yOffset, FACE_WIDTH, FACE_HEIGHT);
			System.out.println("Clipped image to face dimensions: (" +FACE_WIDTH + ", " + FACE_HEIGHT + ")");
		}
		catch(RasterFormatException e)
		{
			System.out.println("Could not clip the image");
			faceIm = grayIm.getBufferedImage();
		}
		return faceIm;
	}  // end of clipToFace()


	private void saveImage(BufferedImage im, String fnm)
	// save image in fnm
	{
		try 
			{
			ImageIO.write(im, "png", new File(fnm));
			System.out.println("Saved image to " + fnm);
			} 
		catch (IOException e)
		{
			System.out.println("Could not save image to " + fnm);
		}
	}  // end of saveImage()
	
} // end of FaceRecognizer class