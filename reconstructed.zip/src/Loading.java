// Loading.java

/* 
 * It shows a GIF in a JWindow and show the processes.
 * @author : Manish Tiwari
 */

import java.awt.*;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.UIManager;
import de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel;
import java.awt.BorderLayout;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class Loading  implements Runnable
{
	final static SpeakName objSpeak=new SpeakName();
    JPanel contentPane;
    JLabel imageLabel = new JLabel();
    static JLabel footerLabel = new JLabel();
    static JWindow w=new JWindow();
    
    public void run()
    {
       try 
       {
            contentPane = (JPanel) w.getContentPane();
            contentPane.setLayout(new BorderLayout());
            w.setSize(new Dimension(780,450));
            //add the image label
            ImageIcon ii = new ImageIcon(this.getClass().getResource("1.gif"));
            imageLabel.setIcon(ii);
            contentPane.add(imageLabel, java.awt.BorderLayout.CENTER);
            contentPane.add(footerLabel, java.awt.BorderLayout.SOUTH);
            // show it
            this.w.setLocationRelativeTo(null);
            this.w.setVisible(true);
        }
       catch (Exception exception)
       {
    	   JOptionPane.showMessageDialog(null,"(: OOPS!Something Wrong!Wait, I Am Fixing For You,Just Kidding :)","Error",JOptionPane.ERROR_MESSAGE);
           exception.printStackTrace();
       }
    }
  
    public static void main(String[] args) throws InvocationTargetException, InterruptedException
    { 
    	try 
		{
    		//add syntheticaBlueIce
    		UIManager.setLookAndFeel(new SyntheticaBlueIceLookAndFeel());
		} catch (Exception e){}
    	/*Invoking The Loading Thread, This Will Show a Splash Screen And the shosw the processes*/
        new Loading().run();
        /*By Invoking This Thread,The Training Images Will Converted Into Eigen-Faces. The Eigen-Faces Is A Kind Of Images 
         * Which Gray-Scale Value Is 1.*/  
        new BuildEigenFaces().run();   
        //Calling FaceRecognizer Constructor
        new FaceRecognizer();
    }
}