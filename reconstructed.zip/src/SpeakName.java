//SpeakName.java
//Manish Tiwari
/*
 * this class is used to speak the name of recognized face.
 * in this i am using freeTTS.
 * freeTTS is an open source project/API for java for text to speak.
 */
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class SpeakName 
{
	static String voiceName="kevin16";
    VoiceManager freettsVM;
    Voice freettsVoice;
    synchronized void speak(String words)
    {
    	System.setProperty("mbrola.base", "mbrola");
        freettsVM = VoiceManager.getInstance();
        freettsVoice = freettsVM.getVoice(voiceName);
        
        freettsVoice.allocate();
        freettsVoice.setRate(110);
        freettsVoice.speak(words);
    }
}